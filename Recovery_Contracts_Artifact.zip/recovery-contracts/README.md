# Recovery Contracts for Post-Quantum Storage Migration

Research artifact and author-review draft for a possible EnCyCriS 2027 short
position paper with executable evidence.

**Authors:** Ishan Teredesai and Tushar Rahangdale. The email spelling
`tusharrahangadle@gmail.com` is intentional.

## What is implemented

- A finite transition model of wrapping-key generations, committed envelopes,
  one retained snapshot, and volatile rewrap intentions.
- A breadth-first explorer that terminates only after all reachable states
  within each chosen finite configuration have been visited.
- A synthetic SQLite/AES-256-GCM envelope-storage harness that terminates a
  worker process at six cut points, plus a normal-completion control.
- Six validation tests, raw outcomes for 126 harness cases, and shortest model
  traces. The largest model configuration has three records and three generations.

The model and harness **do not implement post-quantum cryptography**. They test
key lifecycle dependencies that migration software must preserve. No QRNG,
real remote KMS, hospital deployment, cryptographic security bound, latency
improvement, or production reliability is demonstrated.

## Main results

| Retirement rule | Model states (3 records, 3 generations) | Model states missing live / backup keys | Harness live / backup failure cases |
|---|---:|---:|---:|
| Intent-only | 3,682 | 1,814 / 1,766 | 12 / 30 |
| Live-only | 1,996 | 0 / 403 | 0 / 12 |
| Recovery-set | 1,495 | 0 / 0 | 0 / 0 |

There are 42 harness cases per policy. Failure columns can overlap. They are
case counts, **not** estimated failure probabilities. All 42 recovery-set cases
restore all live records and all snapshot records. Across its six bounded model
configurations, recovery-set explores 1,890 states and 7,232 generated transitions.

## Reproduce

Use Python 3.10 or newer on Linux. The recorded run used Python 3.12.14,
SQLite 3.53.1, and cryptography 50.0.2. SQLite is supplied by Python; its exact
version can differ on another installation. Linux is required for the directory
fsync implementation in the crash harness. Windows users can use WSL/Ubuntu.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
bash run_experiments.sh
```

For the model alone, no third-party Python package is needed:

```bash
python3 experiment/model.py --out results
```

The runner writes results to `results/`; commit or copy existing outputs first
if you want to preserve both environments' manifests. Temporary databases and
synthetic encryption keys are discarded after each harness case.

## Build the documents

With a standard TeX Live installation and `latexmk`:

```bash
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error supplement.tex
```

`paper/IEEEtran.cls` is an unchanged upstream formatting class, included with its
original license and credit notices. See `THIRD_PARTY_NOTICES.md`.

## Files

| Path | Purpose |
|---|---|
| `paper/paper.tex`, `paper/paper.pdf` | Four-page identified manuscript draft |
| `paper/supplement.tex`, `paper/supplement.pdf` | Reproduction instructions, full tables, traces, limits |
| `experiment/model.py` | Abstract state and exhaustive bounded exploration |
| `experiment/crash_harness.py` | Actual process termination and ciphertext restoration |
| `experiment/test_model.py` | Validation tests and small-universe invariant check |
| `results/model_summary.csv` | All 18 bounded configurations |
| `results/model_traces.json` | Shortest witnesses, with every intermediate state |
| `results/crash_trials.csv` | All 126 individual cases |
| `results/*manifest.json` | Source hashes and runtime information |
| `SHA256SUMS` | Integrity hashes for the source and outputs |

## Assumptions and limits

The guarded rule assumes complete dependency information and serialization with
reference creation. A real distributed implementation may violate either
assumption. The model omits ordinary content writes/deletes, multiple snapshots,
replication, key compromise, and parser or authorization failures. The harness
kills a process; it does not cut power or stop the kernel. The two weak policies
are intentionally constructed controls, not reported defects in third-party
products. Profile labels do not establish actual post-quantum security.

## Provenance and submission status

This artifact was newly created and executed while preparing this draft. OpenAI
ChatGPT assisted with model design, code generation, and manuscript drafting;
the paper includes a corresponding disclosure. Authors must review the code,
results, references, and claims before adopting the draft.

A related four-author storage-middleware manuscript has an unresolved venue
status. A confidential related-manuscript disclosure is supplied separately to
the authors; it should accompany any chair assessment of overlap. This repository
and the new title do not certify eligibility, acceptance, or freedom from
duplicate-submission concerns for this or a later paper.
